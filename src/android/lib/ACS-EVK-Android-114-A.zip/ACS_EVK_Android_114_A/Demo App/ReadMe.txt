ACS Smart Card Reader Test Android Demo 
Advanced Card Systems Ltd.

Introduction
------------

The ACS ReaderTestDemo app was designed to be used with ACS USB PC/SC Smart Card Readers.


Installation
------------

1. Copy the "ReaderTest.apk" to your Android device. 
2. Launch the installation by clicking the file icon using any File Explorer application.


Other Apps
----------

For other apps made by ACS for your ACS USB PC/SC Smart Card Readers, please visit Google Play.
 1. ACS-Smart Biz Card 
    - Description: enables users to create, exchage and store business cards in their Android tablets.
    - Link : https://play.google.com/store/apps/details?id=com.acs.businesscard
 2. ACS-Medical Practitioner Demo 
    - Description : shows on utilizing smart cards with tablet PC as an effective tool for an eHealth system. This allows doctors to register a patient card, update and view the patient�s personal information, present medical condition, medical history, diagnosis, and prescription.
     - Link : https://play.google.com/store/apps/details?id=com.acs.patient_demo 
 3. ACS-Personal Medical Report Demo
     - Description: allows patients to view their personal information, medical condition, and the prescribed medication which are securely stored in the Patient Card using the ACOS3.     
     - Link: https://play.google.com/store/apps/details?id=com.acs.patient_demo


Support
-------

In case there any issue encountered, please contact ACS:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286
